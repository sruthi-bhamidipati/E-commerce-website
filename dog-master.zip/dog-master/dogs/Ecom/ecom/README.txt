Hello Welcome!!!

In this project was done by all new official versions,
For best experience you have to practice with new versions.

Some Corrections we did and mention the link also in the

STEP 1: Activate the Environment
        1.cd ecomenv\scripts      (click enter)
        2.activate                (click enter)

STEP 2: Install the the required software
        1.py -m pip install -r requirements.txt         (click enter)

        (NOTE: better to use Python 3.8.0  to 3.9.0 versions)

Step 3: Go to the Project Folder
        1. cd..                    (click enter)
        2. cd..                    (click enter)

Step 4: Enert the Project folder
        1. cd ecom                 (click enter)

Step 5:Run the server
        1. python manage.py runserver   (click enter)

        (NOTE: for changing the add any number end of the above command)